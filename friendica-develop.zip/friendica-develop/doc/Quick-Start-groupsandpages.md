This is the global directory.
If you get lost, you can <a href = "help/Quick-Start-groupsandpages">click this link</a> to bring yourself back here.

On this page, you'll find a collection of groups, forums and celebrity pages.
Groups are not real people.
Connecting to them is similar to "liking" something on Facebook, or signing up for a new forum.
You don't have to feel awkward about introducing yourself to a new person, because they're not people!

When you connect to a group, all messages to that group will start appearing in your network tab.
You can comment on these posts, or post to the group yourself without ever having to add any of the groups members.
This is a great way to make friends dynamically - you'll find people you like and add each other naturally instead of adding random strangers.
Simply find a group you're interested in, and connect to it the same way you did with people in the last section.
There are a lot of groups, and you're likely to get lost.
Remember the link at the top of this page will bring you back here.

Once you've added some groups, <a href="help/Quick-Start-andfinally">move on to the next section</a>.

<iframe src="http://dir.friendica.social/directory" width="950" height="600"></iframe>


