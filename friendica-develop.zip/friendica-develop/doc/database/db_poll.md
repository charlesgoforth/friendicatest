Table poll
==========

| Field | Description | Type       | Null | Key | Default | Extra          |
|-------|-------------|------------|------|-----|---------|----------------|
| id    |             | int(11)    | NO   | PRI | NULL    | auto_increment |
| uid   |             | int(11)    | NO   | MUL | 0       |                |
| q0    |             | mediumtext | NO   |     | NULL    |                |
| q1    |             | mediumtext | NO   |     | NULL    |                |
| q2    |             | mediumtext | NO   |     | NULL    |                |
| q3    |             | mediumtext | NO   |     | NULL    |                |
| q4    |             | mediumtext | NO   |     | NULL    |                |
| q5    |             | mediumtext | NO   |     | NULL    |                |
| q6    |             | mediumtext | NO   |     | NULL    |                |
| q7    |             | mediumtext | NO   |     | NULL    |                |
| q8    |             | mediumtext | NO   |     | NULL    |                |
| q9    |             | mediumtext | NO   |     | NULL    |                |

Return to [database documentation](help/database)
