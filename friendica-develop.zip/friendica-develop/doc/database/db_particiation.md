Table participation
===================

| Field       | Description      | Type             | Null | Key | Default             | Extra |
|-------------|------------------|------------------|------|-----|---------------------|-------|
| iid         | item id          | int(10) unsigned | NO   | PRI |                     |       |
| server      | Name of server   | varchar(60)      | NO   | PRI |                     |       |
| cid         | contact id       | int(10) unsigned | NO   |     |                     |       |

Return to [database documentation](help/database)
