Table pconfic
=============

| Field | Description | Type       | Null | Key | Default | Extra          |
|-------|-------------|------------|------|-----|---------|----------------|
| id    |             | int(11)    | NO   | PRI | NULL    | auto_increment |
| uid   |             | int(11)    | NO   | MUL | 0       |                |
| cat   |             | char(255)  | NO   |     |         |                |
| k     |             | char(255)  | NO   |     |         |                |
| v     |             | mediumtext | NO   |     | NULL    |                |

Return to [database documentation](help/database)
