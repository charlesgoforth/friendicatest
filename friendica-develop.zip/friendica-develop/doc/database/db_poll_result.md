Table poll_result
=================

| Field   | Description      | Type    | Null | Key | Default | Extra          |
|---------|------------------|---------|------|-----|---------|----------------|
| id      | sequential ID    | int(11) | NO   | PRI | NULL    | auto_increment |
| poll_id |                  | int(11) | NO   | MUL | 0       |                |
| choice  |                  | int(11) | NO   | MUL | 0       |                |

Return to [database documentation](help/database)
