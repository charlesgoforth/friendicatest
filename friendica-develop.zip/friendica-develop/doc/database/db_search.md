Table search
============

| Field | Description      | Type         | Null | Key | Default | Extra          |
|-------|------------------|--------------|------|-----|---------|----------------|
| id    | sequential ID    | int(11)      | NO   | PRI | NULL    | auto_increment |
| uid   |                  | int(11)      | NO   | MUL | 0       |                |
| term  |                  | varchar(255) | NO   | MUL |         |                |

Return to [database documentation](help/database)
