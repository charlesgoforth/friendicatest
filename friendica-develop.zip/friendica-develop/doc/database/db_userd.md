Table userd
===========

| Field    | Description      | Type         | Null | Key | Default | Extra          |
|----------|------------------|--------------|------|-----|---------|----------------|
| id       | sequential ID    | int(11)      | NO   | PRI | NULL    | auto_increment |
| username |                  | varchar(255) | NO   | MUL | NULL    |                |

Return to [database documentation](help/database)
