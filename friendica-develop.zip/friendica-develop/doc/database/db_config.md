Table config
============

| Field | Description | Type             | Null | Key | Default | Extra           |
| ----- | ----------- | ---------------- | ---- | --- | ------- | --------------- |
| id    |             | int(10) unsigned | NO   | PRI | NULL    | auto_increment  |
| cat   |             | char(255)        | NO   | MUL |         |                 |
| k     |             | char(255)        | NO   |     |         |                 |
| v     |             | text             | NO   |     | NULL    |                 |

Return to [database documentation](help/database)
