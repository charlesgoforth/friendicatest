Table challenge
===============

| Field       | Description      | Type             | Null | Key | Default | Extra          |
|-------------|------------------|------------------|------|-----|---------|----------------|
| id          | sequential ID    | int(10) unsigned | NO   | PRI | NULL    | auto_increment |
| challenge   |                  | varchar(255)     | NO   |     |         |                |
| dfrn-id     |                  | varchar(255)     | NO   |     |         |                |
| expire      |                  | int(11)          | NO   |     | 0       |                |
| type        |                  | varchar(255)     | NO   |     |         |                |
| last_update |                  | varchar(255)     | NO   |     |         |                |

Return to [database documentation](help/database)
