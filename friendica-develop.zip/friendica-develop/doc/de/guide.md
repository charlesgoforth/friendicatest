Erste Schritte... 
==========

* [Zur Startseite der Hilfe](help)

Das Erste zum Anfang: geh sicher, dass du schon eingeloggt bist. 
Wenn du noch nicht eingeloggt bist, kannst du das in dem Fenster unten machen. 

Sobald du eingeloggt bist (oder wenn du bereits eingeloggt bist), kannst du unten nun auf deine Profilseite schauen.

Hier sieht es ein wenig wie auf deiner Facebook-Seite aus. 
Hier findest du alle deine Statusmeldungen und Nachrichten deiner Freunde, die direkt auf deine Seite ("Wall") geschrieben haben. 
Um deinen Status einzutragen, klicke einfach auf die Box oben, in der "Teilen" steht. 
Wenn du das machst, vergrößert sich die Box. 
Nun kannst du einige Formatierungsoptionen wie Fett, kursiv, unterstrichen auswählen und ebenfalls Bilder und Links hinzufügen. 
Unten findest du in diesem Feld weitere Links, mit denen du Bilder und Dateien von deinem Computer hochladen, Webseiten mit einem Kurztext teilen und Video- und Audiodateien aus dem Internet einfügen kannst. 
Außerdem kannst du hier eintragen, wo du gerade bist. 

Wenn du deinen Beitrag ("Post") geschrieben hast, kannst du auf das "Schloss"-Symbol klicken und festlegen, wer deinen Beitrag sehen kann. 
Wenn du dieses Symbol nicht anklickst, ist dein Beitrag öffentlich. 
Das bedeutet, dass jeder, der dein Profil ansieht, der auf dem "Community"-Tab deines Servers oder auf dem "Netzwerk"-Tab ("Beiträge deiner Kontakte") eines befreundeten Kontakts ist, den Beitrag sehen kann.

Probiere es doch einfach mal aus. Wenn du fertg bist, schauen wir uns den <a href="help/network">"Netzwerk"-Tab</a> an. 

<iframe src="login" width="950" height="600"></iframe>

