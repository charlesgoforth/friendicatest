Neue Freunde finden
==============

* [Zur Startseite der Hilfe](help)

Hier siehst Du die Kontaktvorschläge. 
Wenn Du Dich mal verirrt hast, kannst Du diesen Link klicken und wieder hierher kommen.

Diese Seite funktioniert in etwa wie die Seite für Kontaktvorschläge in Facebook. 
Jeder auf dieser Liste hat zugestimmt, als Kontaktvorschlag zu erscheinen. 
Das bedeutet, das sie Anfragen meist nicht ablehnen, da sie neue Leute kennenlernen wollen.

Siehst Du jemanden, der Dir interessant erscheint? 
Klicke auf den "Verbinden"-Knopf beim Foto. 
Als nächstes kommst Du zur Seite "Freundschafts-/Kontaktanfrage". 
Fülle das Formular wie vorgegeben aus und trage optional eine kleine Notiz ein. 
Nun musst Du nur noch auf die Bestätigung warten. 
Beachte dabei, dass es sich um reale Personen handelt und es somit etwas dauern kann.

Jetzt, nachdem Du jemanden hinzugefügt hast, weißt Du vielleicht nicht mehr, wie Du zurückkommst. 
Klicke einfach auf den Link oben auf dieser Seite und Du gelangst zur Seite mit den Kontaktvorschlägen zurück, um weitere Personen hinzuzufügen.

Du willst nicht einfach Personen hinzufügen, die du nicht kennst? 
Kein Problem - an dieser Stelle kommen wir zu den <a href="help/Quick-Start-groupsandpages">Gruppen und Seiten</a>.

<iframe src="suggest" width="950" height="600"></iframe>


