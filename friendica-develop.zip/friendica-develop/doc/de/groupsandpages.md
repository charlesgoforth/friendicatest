Gruppen und Seiten 
==========

* [Zur Startseite der Hilfe](help)

Hier siehst du das globale Verzeichnis. 
Wenn du dich mal verirrt hast, kannst du <a href = "help/groupsandpages">diesen Link klicken</a> und wieder hierher kommen. 

Auf dieser Seite findest du eine Zusammenstellung von Gruppen, Foren und bekannten Seiten. 
Gruppen sind keine realen Personen. 
Sich mit diesen zu verbinden ist, als wenn man jemanden auf Facebook "liked" ("gefällt mir") oder wenn man sich in einem Forum anmeldet. 
Habe keine Sorge, falls du dich unbehaglich fühlst, wenn du dich einer neuen Person vorstellen sollst, da es sich nicht um Personen handelt.

Wenn du dich mit einer Gruppe verbindest, erscheinen alle Nachrichten der Gruppe in deinem "Netzwerk"-Tab. 
Du kannst diese Beiträge kommentieren oder selbst in der Gruppe schreiben, ohne eine der Gruppenmitglieder persönlich hinzuzufügen. 
Das ist ein großartiger Weg, dynamisch neue Freunde zu gewinnen. 
Du findest Personen, die du magst, anstatt Fremde hinzuzufügen. 
Suche dir einfach eine Gruppe und füge sie so hinzu, wie du auch normale Freunde hinzufügst. 
Es gibt eine Menge Gruppen und möglicherweise findest du nicht wieder zu dieser Seite zurück. 
In diesem Fall nutze einfach den Link oben auf dieser Seite.

Wenn du einige Gruppen hinzugefügt hast, gehe <a href="help/andfinally">weiter zum nächsten Schritt</a>.

<iframe src="https://dir.friendica.social/home" width="950" height="600"></iframe>


