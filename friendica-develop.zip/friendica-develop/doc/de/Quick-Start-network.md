Deine "Netzwerk"-Seite
==============

* [Zur Startseite der Hilfe](help)

Dies ist Dein "Netzwerk"-Tab. 
Wenn Du Dich mal verirrt hast, kannst Du diesen Link klicken, um wieder hierher zu kommen.

Diese Seite ist ein wenig wie die News-Seite in Facebook oder der Stream in Diaspora. 
Hier findest Du alle Beiträge Deiner Kontakte, Gruppen und Feeds, die Du eingetragen hast. 
Wenn Du neu bist, siehst Du hier noch nichts, falls Du an Deinem Status im letzten Schritt noch nichts geändert haben solltest. 
Wenn Du bereits ein paar Freunde gefunden hast, so findest Du hier ihre Beiträge. 
Du kannst ihre Beiträge von hier aus kommentieren, mitteilen, dass Du den Beitrag magst oder ablehnst (Daumen hoch, Daumen runter) oder die Profile durch einen Klick auf deren Namen besuchen und dort auf deren "Pinnwand" ("Wall") Nachrichten schreiben.

Nun wollen wir diese Seite mit Inhalt füllen. 
Der erste Schritt ist es, <a href="help/Quick-Start-makingnewfriends">Leute zu Deinem Account hinzuzufügen</a>.

<iframe src="network" width="950" height="600"></iframe>


