Gruppen und Seiten 
==========

* [Zur Startseite der Hilfe](help)

Hier siehst Du das globale Verzeichnis. 
Wenn Du Dich mal verirrt hast, kannst Du diesen Link klicken und wieder hierher kommen.

Auf dieser Seite findest Du eine Zusammenstellung von Gruppen, Foren und Promi-Seiten. 
Gruppen sind keine realen Personen. 
Sich mit diesen zu verbinden ist, als wenn man jemanden auf Facebook "liked" ("gefällt mir") oder wenn man sich in einem Forum anmeldet. 
Du musst nicht unsicher sein, ob Du jemandem zu nahe trittst, wenn Du Dich so ohne weiteres mit einer Gruppe verbindest; es handelt sich eben nicht um reale Personen.

Wenn Du Dich mit einer Gruppe verbindest, erscheinen alle Nachrichten der Gruppe in Deinem "Netzwerk"-Tab. 
Du kannst diese Beiträge kommentieren oder selbst in der Gruppe schreiben, ohne eines der Gruppenmitglieder persönlich hinzuzufügen. 
Das ist ein großartiger Weg, dynamisch neue Freunde zu gewinnen. 
Du findest Personen Deines Interesses, anstatt Fremde hinzuzufügen. 
Suche Dir einfach eine Gruppe und füge sie so hinzu, wie Du auch normale Freunde hinzufügst. 
Es gibt eine Menge Gruppen. 
Solltest Du beim Stöbern durch die vielen Gruppen nicht wieder hierher zurück finden, so nutze einfach den Link oben auf dieser Seite.

Wenn Du einige Gruppen hinzugefügt hast, gehe <a href="help/Quick-Start-andfinally">weiter zum nächsten Schritt</a>.

<iframe src="https://dir.friendica.social/home" width="950" height="600"></iframe>


