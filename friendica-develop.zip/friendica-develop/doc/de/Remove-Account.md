Accounts löschen
==============

* [Zur Startseite der Hilfe](help)

Wir freuen uns nicht, wenn Leute Friendica verlassen, aber wenn du deinen Account löschen willst, dann besuche die folgende URL

[Lösche mich (http://NamederSeite/removeme)](../removeme)

in deinem Webbrowser. Du musst dabei eingeloggt sein. 

Du wirst nach deinem Passwort gefragt, um die Anfrage zu bestätigen. 
Wenn dieses mit deinem gespeichertem Passwort übereinstimmt, dann wird dein Account sofort gelöscht. 
Anders als andere Netzwerke, behalten wir die Daten **nicht** für eine gewisse Zeit, falls du deine Meinung noch änderst. 
Deine Nutzerdetails, deine Unterhaltungen, deine Photos, deine Freunde - alles; wird sofort gelöscht und du wirst ausgeloggt.

Wenn Beiträge ablaufen, schicken wir Mitteilungen an Friendica, um diese zu löschen. 
Diaspora hat keine automatische Löschfunktion, so dass diese Funktion in dem Netzwerk deaktiviert ist. 
Und hoffentlich ist klar, dass das Löschen auch in anderen Netzwerken nicht funktioniert. 
Wenn du manuell einen Beitrag bzw. eine Reihe von Beiträgen löschst, dann senden wir individuelle Mitteilungen zu Friendica und Diaspora für jeden gelöschten Post. 

Diaspora versäumt dieses oft.

Wenn du einen Beitrag löscht, aber jemand diesem Beitrag folgt, wird es trotzdem gelöscht. 
Dein Wunsch hat Priorität. 

Wenn du deinen Account löscht, dann löschen wir alle Beiträge, dein Profil, die Nutzerdaten etc. sofort. 

Um einen Gesamtlöschauftrag zu versenden, bräuchten wir zunächst noch deinen Account; auch, um deinen Freunden zu zeigen, wer diese Anfrage stellt. 
Das können wir nicht tun, wenn du keinen Account mehr hast. 

Deine Freunde können möglicherweise noch deine Beiträge sehen, wenn dein Account gelöscht wurde, aber es gibt keinen öffentlichen Ort in Friendica mehr, wo diese angeschaut werden können. 
Wenn du Freunde bei Diaspora hast, kann es sein, dass deine Beiträge weiterhin vorhanden und für andere aus diesem Netzwerk sichtbar sind. 
