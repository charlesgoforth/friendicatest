... und zuletzt
===============

Und damit sind wir auch schon am Ende der Schnellstartanleitung. 

Hier sind noch einige weitere Dinge, die Dir den Start vereinfachen können. 

**Gruppen**


- <a href="http://forum.friendi.ca/profile/helpers">Friendica Support</a> - Probleme?  Dann ist das der Platz, um zu fragen!

**Dokumentation**

- <a href="help/Connectors">Zu weiteren Netzwerken verbinden</a>
- <a href="help">Zur Startseite der Hilfe</a>


