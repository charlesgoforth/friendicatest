Keyboard shortcuts in Friendica
=======================

* [Home](help)

General
-------

* j: Scroll to next thread
* k: Scroll to previous thread
