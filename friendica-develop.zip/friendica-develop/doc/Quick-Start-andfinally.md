And that brings the Quick Start to an end.

Here are some more things to help get you started:

**Groups**


- <a href="http://forum.friendi.ca/profile/helpers">Friendica Support</a> - problems?  This is the place to ask.

**Documentation**

- <a href="help/Connectors">Connecting to more networks</a>
- <a href="help">Help Index</a>


