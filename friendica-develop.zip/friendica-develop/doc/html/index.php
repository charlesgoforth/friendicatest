<!DOCTYPE html>
<html>
<head>
	<title>$Projectname Doxygen API Documentation</title>
</head>
<body>
<h1>$Projectname Doxygen API Documentation not rendered</h1>

To get the Doxygen API Documentation you must render it with the program <a href="http://www.doxygen.org">Doxygen</a> (included in most distributions).
<pre>
$ doxygen Doxyfile
</pre>
<br>
<a href="javascript:history.back()">back</a>
</body>
</html>
