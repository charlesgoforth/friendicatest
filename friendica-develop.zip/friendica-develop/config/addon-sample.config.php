<?php

// Addon configuration

// Copy this configuration file to addon.config.php and edit it if you want to configure addons, see below example for the twitter addon

return [
	'twitter' => [
		'consumerkey' => '1234567890',
		'consumersecret' => 'ABCDEFGHIJKLMONPQRSTUVWXYZ',
	],
];
