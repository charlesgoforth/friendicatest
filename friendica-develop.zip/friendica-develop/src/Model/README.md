## Friendica\Model

Models are the glue between the business logic of the app and the datastore(s).

In the namespace Model should only be static classes that interact with the DB with the same name as a database table.