## Friendica\Core

The Core namespace contains classes, which are essential to Friendica.
 