<?php

namespace Friendica\Module;

use Friendica\App;
use Friendica\BaseModule;
use Friendica\Core;
use Friendica\Core\Config\Cache\IConfigCache;
use Friendica\Core\L10n;
use Friendica\Core\Renderer;
use Friendica\Util\Strings;
use Friendica\Util\Temporal;

class Install extends BaseModule
{
	/**
	 * Step one - System check
	 */
	const SYSTEM_CHECK = 1;
	/**
	 * Step two - Database configuration
	 */
	const DATABASE_CONFIG = 2;
	/**
	 * Step three - Adapat site settings
	 */
	const SITE_SETTINGS = 3;
	/**
	 * Step four - All steps finished
	 */
	const FINISHED = 4;

	/**
	 * @var int The current step of the wizard
	 */
	private static $currentWizardStep;

	/**
	 * @var Core\Installer The installer
	 */
	private static $installer;

	public static function init()
	{
		$a = self::getApp();

		// route: install/testrwrite
		// $baseurl/install/testrwrite to test if rewrite in .htaccess is working
		if ($a->getArgumentValue(1, '') == 'testrewrite') {
			// Status Code 204 means that it worked without content
			Core\System::httpExit(204);
		}

		// We overwrite current theme css, because during install we may not have a working mod_rewrite
		// so we may not have a css at all. Here we set a static css file for the install procedure pages
		Renderer::$theme['stylesheet'] = $a->getBaseURL() . '/view/install/style.css';

		self::$installer = new Core\Installer();
		self::$currentWizardStep = defaults($_POST, 'pass', self::SYSTEM_CHECK);
	}

	public static function post()
	{
		$a = self::getApp();
		$configCache = $a->getConfigCache();

		switch (self::$currentWizardStep) {
			case self::SYSTEM_CHECK:
			case self::DATABASE_CONFIG:
				self::checkSetting($configCache, $_POST, 'config', 'php_path');
				break;

			case self::SITE_SETTINGS:
				self::checkSetting($configCache, $_POST, 'config', 'php_path');

				self::checkSetting($configCache, $_POST, 'database', 'hostname', Core\Installer::DEFAULT_HOST);
				self::checkSetting($configCache, $_POST, 'database', 'username', '');
				self::checkSetting($configCache, $_POST, 'database', 'password', '');
				self::checkSetting($configCache, $_POST, 'database', 'database', '');

				// If we cannot connect to the database, return to the previous step
				if (!self::$installer->checkDB($configCache, $a->getProfiler())) {
					self::$currentWizardStep = self::DATABASE_CONFIG;
				}

				break;

			case self::FINISHED:
				self::checkSetting($configCache, $_POST, 'config', 'php_path');

				self::checkSetting($configCache, $_POST, 'database', 'hostname', Core\Installer::DEFAULT_HOST);
				self::checkSetting($configCache, $_POST, 'database', 'username', '');
				self::checkSetting($configCache, $_POST, 'database', 'password', '');
				self::checkSetting($configCache, $_POST, 'database', 'database', '');

				self::checkSetting($configCache, $_POST, 'system', 'default_timezone', Core\Installer::DEFAULT_TZ);
				self::checkSetting($configCache, $_POST, 'system', 'language', Core\Installer::DEFAULT_LANG);
				self::checkSetting($configCache, $_POST, 'config', 'admin_email', '');

				// If we cannot connect to the database, return to the Database config wizard
				if (!self::$installer->checkDB($configCache, $a->getProfiler())) {
					self::$currentWizardStep = self::DATABASE_CONFIG;
					return;
				}

				if (!self::$installer->createConfig($a, $configCache, $a->getBasePath())) {
					return;
				}

				self::$installer->installDatabase($a->getBasePath());

				break;
		}
	}

	public static function content()
	{
		$a = self::getApp();
		$configCache = $a->getConfigCache();

		$output = '';

		$install_title = L10n::t('Friendica Communications Server - Setup');

		switch (self::$currentWizardStep) {
			case self::SYSTEM_CHECK:
				$php_path = $configCache->get('config', 'php_path');

				$status = self::$installer->checkEnvironment($a->getBaseURL(), $php_path);

				$tpl = Renderer::getMarkupTemplate('install_checks.tpl');
				$output .= Renderer::replaceMacros($tpl, [
					'$title'        => $install_title,
					'$pass'         => L10n::t('System check'),
					'$checks'       => self::$installer->getChecks(),
					'$passed'       => $status,
					'$see_install'  => L10n::t('Please see the file "INSTALL.txt".'),
					'$next'         => L10n::t('Next'),
					'$reload'       => L10n::t('Check again'),
					'$php_path'     => $php_path,
					'$baseurl'      => $a->getBaseURL()
				]);
				break;

			case self::DATABASE_CONFIG:
				$tpl = Renderer::getMarkupTemplate('install_db.tpl');
				$output .= Renderer::replaceMacros($tpl, [
					'$title'    => $install_title,
					'$pass'     => L10n::t('Database connection'),
					'$info_01'  => L10n::t('In order to install Friendica we need to know how to connect to your database.'),
					'$info_02'  => L10n::t('Please contact your hosting provider or site administrator if you have questions about these settings.'),
					'$info_03'  => L10n::t('The database you specify below should already exist. If it does not, please create it before continuing.'),
					'checks'    => self::$installer->getChecks(),
					'$dbhost'   => ['database-hostname',
									L10n::t('Database Server Name'),
									$configCache->get('database', 'hostname'),
									'',
									'required'],
					'$dbuser'   => ['database-username',
									L10n::t('Database Login Name'),
									$configCache->get('database', 'username'),
									'',
									'required',
									'autofocus'],
					'$dbpass'   => ['database-password',
									L10n::t('Database Login Password'),
									$configCache->get('database', 'password'),
									L10n::t("For security reasons the password must not be empty"),
									'required'],
					'$dbdata'   => ['database-database',
									L10n::t('Database Name'),
									$configCache->get('database', 'database'),
									'',
									'required'],
					'$lbl_10'   => L10n::t('Please select a default timezone for your website'),
					'$baseurl'  => $a->getBaseURL(),
					'$php_path' => $configCache->get('config', 'php_path'),
					'$submit'   => L10n::t('Submit')
				]);
				break;

			case self::SITE_SETTINGS:
				/* Installed langs */
				$lang_choices = L10n::getAvailableLanguages();

				$tpl = Renderer::getMarkupTemplate('install_settings.tpl');
				$output .= Renderer::replaceMacros($tpl, [
					'$title' 		=> $install_title,
					'$checks' 		=> self::$installer->getChecks(),
					'$pass' 		=> L10n::t('Site settings'),
					'$dbhost' 		=> $configCache->get('database', 'hostname'),
					'$dbuser' 		=> $configCache->get('database', 'username'),
					'$dbpass' 		=> $configCache->get('database', 'password'),
					'$dbdata' 		=> $configCache->get('database', 'database'),
					'$phpath' 		=> $configCache->get('config', 'php_path'),
					'$adminmail'	=> ['config-admin_email',
										L10n::t('Site administrator email address'),
										$configCache->get('config', 'admin_email'),
										L10n::t('Your account email address must match this in order to use the web admin panel.'),
										'required', 'autofocus', 'email'],
					'$timezone' 	=> Temporal::getTimezoneField('system-default_timezone',
										L10n::t('Please select a default timezone for your website'),
										$configCache->get('system', 'default_timezone'),
									''),
					'$language' 	=> ['system-language',
										L10n::t('System Language:'),
										$configCache->get('system', 'language'),
										L10n::t('Set the default language for your Friendica installation interface and to send emails.'),
										$lang_choices],
					'$baseurl' 		=> $a->getBaseURL(),
					'$submit' 		=> L10n::t('Submit')
				]);
				break;

			case self::FINISHED:
				$db_return_text = "";

				if (count(self::$installer->getChecks()) == 0) {
					$txt = '<p style="font-size: 130%;">';
					$txt .= L10n::t('Your Friendica site database has been installed.') . EOL;
					$db_return_text .= $txt;
				}

				$tpl = Renderer::getMarkupTemplate('install_finished.tpl');
				$output .= Renderer::replaceMacros($tpl, [
					'$title'  => $install_title,
					'$checks' => self::$installer->getChecks(),
					'$pass'   => L10n::t('Installation finished'),
					'$text'   => $db_return_text . self::whatNext($a),
				]);

				break;
		}

		return $output;
	}

	/**
	 * Creates the text for the next steps
	 *
	 * @param App $a The global App
	 *
	 * @return string The text for the next steps
	 * @throws \Friendica\Network\HTTPException\InternalServerErrorException
	 */
	private static function whatNext($a)
	{
		$baseurl = $a->getBaseUrl();
		return
			L10n::t('<h1>What next</h1>')
			. "<p>".L10n::t('IMPORTANT: You will need to [manually] setup a scheduled task for the worker.')
			. L10n::t('Please see the file "INSTALL.txt".')
			. "</p><p>"
			. L10n::t('Go to your new Friendica node <a href="%s/register">registration page</a> and register as new user. Remember to use the same email you have entered as administrator email. This will allow you to enter the site admin panel.', $baseurl)
			. "</p>";
	}

	/**
	 * Checks the $_POST settings and updates the config Cache for it
	 *
	 * @param IConfigCache $configCache The current config cache
	 * @param array        $post        The $_POST data
	 * @param string       $cat         The category of the setting
	 * @param string       $key         The key of the setting
	 * @param null|string  $default     The default value
	 */
	private static function checkSetting(IConfigCache $configCache, array $post, $cat, $key, $default = null)
	{
		$configCache->set($cat, $key,
			Strings::escapeTags(
				trim(defaults($post, sprintf('%s-%s', $cat, $key),
						(!isset($default) ? $configCache->get($cat, $key) : $default))
				)
			)
		);
	}
}
