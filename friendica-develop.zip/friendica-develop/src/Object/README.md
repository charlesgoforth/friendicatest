## Friendica\Object

The namespace Object contains dynamic classes which are **not** directly interacting with the datastore.

They are used to implement business logic for a particular object (i.e. an Image). 